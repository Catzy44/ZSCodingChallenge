package me.kotsu.parser.json.dto;

public record DataWrapperDTO(int[] elements) {}
