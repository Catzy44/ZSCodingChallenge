package me.kotsu.sort;

public interface SortingAlgorithm {
	void sort(int[] data);
}
