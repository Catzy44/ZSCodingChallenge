package me.kotsu.data;

public interface DataProviderConfig {
	
}
